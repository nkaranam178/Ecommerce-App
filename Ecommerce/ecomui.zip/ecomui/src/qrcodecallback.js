qrcode.callback = res => {
    const qrResult = document.getElementById("qr-result");
    const canvasElement = document.getElementById("qr-canvas");
    console.log("Inside callback")
    if (res) {
      console.log("Result is "+res)
      // outputData.innerText = res;
      scanning = false;
  
      video.srcObject.getTracks().forEach(track => {
        track.stop();
      });
  
      qrResult.hidden = false;
      canvasElement.hidden = true;
    }
  };