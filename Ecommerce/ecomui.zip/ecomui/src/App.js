import React from 'react';
import {useEffect} from 'react';
// import logo from './logo.svg';
import './App.css';

const qrcode = window.qrcode;
const video = document.createElement("video");
let scanning = false;


console.log(qrcode)

function App() {
  
  useEffect(() => {
    const script = document.createElement('script')
    const callbackScript = document.createElement('script')
    callbackScript.type = "text/javascript";
    callbackScript.async = true;
    script.type = "text/javascript";
    script.async = true;
    callbackScript.src = "https://raw.githubusercontent.com/sackot007/product-service/master/qrcodecallback.js"
    script.src = "https://rawgit.com/sitepoint-editors/jsqrcode/master/src/qr_packed.js"
    
    document.body.appendChild(script);
    document.body.appendChild(callbackScript);
    
    return () => {
      document.body.removeChild(script);
      document.body.removeChild(callbackScript);
    }
  }, [])

  return (
    <div className="App">
      <h2>Ecom UI</h2>
  
      <input type="text" id="itemID" name="itemID" placeholder="Search item"/>
      <button onClick={searchDB}>Search</button>
      <br></br>
      <button onClick={scanBarCode}id="Scan">Scan</button> <br></br>
      <canvas hidden="" id="qr-canvas"></canvas>

      <div id="qr-result" hidden="">
        <b>Data:</b> <span id="outputData"></span>
      </div>

    </div>
  );
}

  function scanBarCode(){
    const qrResult = document.getElementById("qr-result");
    const canvasElement = document.getElementById("qr-canvas");
    // const canvas = canvasElement.getContext("2d");

    navigator.mediaDevices
    .getUserMedia({ video: { facingMode: "environment" } })
    .then(function(stream) {
      scanning = true;
      qrResult.hidden = true;
      // btnScanQR.hidden = true;
      canvasElement.hidden = false;
      video.setAttribute("playsinline", true); // required to tell iOS safari we don't want fullscreen
      video.srcObject = stream;
      video.play();
      tick();
      scan();
    });
    
    return null;  
  }

  function tick() {
    const canvasElement = document.getElementById("qr-canvas");
    const canvas = canvasElement.getContext("2d");
    canvasElement.height = video.videoHeight;
    canvasElement.width = video.videoWidth;
    canvas.drawImage(video, 0, 0, canvasElement.width, canvasElement.height);
  
    scanning && requestAnimationFrame(tick);
  }
  
  function scan() {

    try {
      console.log("Inside scan try");
      
      qrcode.decode();
      
    } catch (e) {
      setTimeout(scan, 300);
    }
  }
  

  function searchDB(){
    return null;
  }

  

export default App;
